-- ============================================
-- MySQL Queries for Migration: Rename Treatment/Disease Other Fields
-- Migration: 2025_11_05_203929_add_treatment_disease_other_fields_to_patient_appointments_table.php
-- ============================================

-- ============================================
-- UP Migration (Forward)
-- ============================================

-- Step 1: Drop old columns if they exist
ALTER TABLE `patient_appointments` 
DROP COLUMN IF EXISTS `patient_type_of_treatment_other_snapshot`;

ALTER TABLE `patient_appointments` 
DROP COLUMN IF EXISTS `patient_other_diseases_other_snapshot`;

-- Step 2: Add new columns with simpler names
ALTER TABLE `patient_appointments` 
ADD COLUMN `patient_treatment_other` VARCHAR(255) NULL AFTER `patient_type_of_treatment`;

ALTER TABLE `patient_appointments` 
ADD COLUMN `patient_disease_other` VARCHAR(255) NULL AFTER `patient_other_diseases`;


-- ============================================
-- DOWN Migration (Rollback) - Reverse the above
-- ============================================

-- Step 1: Drop new columns
ALTER TABLE `patient_appointments` 
DROP COLUMN IF EXISTS `patient_treatment_other`;

ALTER TABLE `patient_appointments` 
DROP COLUMN IF EXISTS `patient_disease_other`;

-- Step 2: Restore old columns
ALTER TABLE `patient_appointments` 
ADD COLUMN `patient_type_of_treatment_other_snapshot` VARCHAR(255) NULL AFTER `patient_type_of_treatment`;

ALTER TABLE `patient_appointments` 
ADD COLUMN `patient_other_diseases_other_snapshot` VARCHAR(255) NULL AFTER `patient_other_diseases`;


-- ============================================
-- SAFE VERSION (With Column Existence Checks)
-- Use this if you want to check before altering
-- ============================================

-- UP Migration (Safe Version)
SET @dbname = DATABASE();
SET @tablename = 'patient_appointments';

-- Drop patient_type_of_treatment_other_snapshot if exists
SET @columnname1 = 'patient_type_of_treatment_other_snapshot';
SET @preparedStatement1 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname1)
    ) > 0,
    CONCAT("ALTER TABLE `", @tablename, "` DROP COLUMN `", @columnname1, "`;"),
    "SELECT 'Column patient_type_of_treatment_other_snapshot does not exist.' AS result;"
));
PREPARE alterIfExists1 FROM @preparedStatement1;
EXECUTE alterIfExists1;
DEALLOCATE PREPARE alterIfExists1;

-- Drop patient_other_diseases_other_snapshot if exists
SET @columnname2 = 'patient_other_diseases_other_snapshot';
SET @preparedStatement2 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname2)
    ) > 0,
    CONCAT("ALTER TABLE `", @tablename, "` DROP COLUMN `", @columnname2, "`;"),
    "SELECT 'Column patient_other_diseases_other_snapshot does not exist.' AS result;"
));
PREPARE alterIfExists2 FROM @preparedStatement2;
EXECUTE alterIfExists2;
DEALLOCATE PREPARE alterIfExists2;

-- Add patient_treatment_other if not exists
SET @columnname3 = 'patient_treatment_other';
SET @preparedStatement3 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname3)
    ) > 0,
    "SELECT 'Column patient_treatment_other already exists.' AS result;",
    CONCAT("ALTER TABLE `", @tablename, "` ADD COLUMN `", @columnname3, "` VARCHAR(255) NULL AFTER `patient_type_of_treatment`;")
));
PREPARE alterIfNotExists3 FROM @preparedStatement3;
EXECUTE alterIfNotExists3;
DEALLOCATE PREPARE alterIfNotExists3;

-- Add patient_disease_other if not exists
SET @columnname4 = 'patient_disease_other';
SET @preparedStatement4 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname4)
    ) > 0,
    "SELECT 'Column patient_disease_other already exists.' AS result;",
    CONCAT("ALTER TABLE `", @tablename, "` ADD COLUMN `", @columnname4, "` VARCHAR(255) NULL AFTER `patient_other_diseases`;")
));
PREPARE alterIfNotExists4 FROM @preparedStatement4;
EXECUTE alterIfNotExists4;
DEALLOCATE PREPARE alterIfNotExists4;


<?php

namespace App\Exports;

use App\Models\Patient;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class PatientsExport implements FromCollection, WithHeadings, WithMapping, WithStyles, WithColumnWidths
{
    protected $doctorId;
    protected $filters;

    public function __construct($doctorId = null, $filters = [])
    {
        $this->doctorId = $doctorId;
        $this->filters = $filters;
    }

    public function collection()
    {
		// Load all patients with filtered appointments (shared patient system)
		$query = Patient::with(['createdByDoctor']);
		
		// If doctor is exporting, restrict to only patients having appointments with that doctor
		if ($this->doctorId) {
			$query->whereHas('appointments', function($appointmentQuery) {
				$appointmentQuery->where('doctor_id', $this->doctorId);
			});
			$query->with(['appointments' => function($appointmentQuery) {
				$appointmentQuery->where('doctor_id', $this->doctorId)
					->orderBy('visit_date_time', 'desc');
			}]);
		} else {
			// Admin exports all appointments
			$query->with('appointments');
		}
        
        // Apply filters
        if (!empty($this->filters['search'])) {
            $search = $this->filters['search'];
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('mobile_number', 'like', "%{$search}%")
                  ->orWhere('sssp_id', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        if (!empty($this->filters['sex'])) {
            $query->where('sex', $this->filters['sex']);
        }

        if (!empty($this->filters['age'])) {
            $query->where('age', $this->filters['age']);
        }

        // Last visit date range filter (based on appointments by current doctor)
        if (!empty($this->filters['last_visit_from'])) {
            $query->whereHas('appointments', function($appointmentQuery) {
                if ($this->doctorId) {
                    $appointmentQuery->where('doctor_id', $this->doctorId);
                }
                $appointmentQuery->whereDate('visit_date_time', '>=', $this->filters['last_visit_from']);
            });
        }

        if (!empty($this->filters['last_visit_to'])) {
            $query->whereHas('appointments', function($appointmentQuery) {
                if ($this->doctorId) {
                    $appointmentQuery->where('doctor_id', $this->doctorId);
                }
                $appointmentQuery->whereDate('visit_date_time', '<=', $this->filters['last_visit_to']);
            });
        }
        
        return $query->get();
    }

    public function headings(): array
    {
		return [
			// Required leading fields in exact order
			'SSSP ID',
			'Name',
			'Mobile Number',
			'Date of Birth',
			'Age',
			'Sex',
			'Address',
			'BMI',
			'Last visit Date'
		];
    }

	public function map($patient): array
    {
        // Use the pre-loaded filtered appointments
        $latestAppointment = $patient->appointments->first();
		
		return [
			// Required leading fields
			$patient->sssp_id,
			$patient->name,
			$patient->mobile_number,
			$patient->date_of_birth ? $patient->date_of_birth->format('M d, Y') : 'Not specified',
			$patient->age,
			ucfirst($patient->sex),
			$patient->short_address,
			$patient->bmi ?? 'Not calculated',
			$latestAppointment ? $latestAppointment->visit_date_time->format('M d, Y H:i') : 'No appointments'
		];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            // Style the first row as bold text
            1 => ['font' => ['bold' => true]],
        ];
    }

	public function columnWidths(): array
    {
		return [
			'A' => 15, // SSSP ID
			'B' => 25, // Name
			'C' => 15, // Mobile Number
			'D' => 14, // Date of Birth
			'E' => 8,  // Age
			'F' => 8,  // Sex
			'G' => 30, // Address
			'H' => 10, // BMI
			'I' => 18, // Last visit Date
		];
    }
}
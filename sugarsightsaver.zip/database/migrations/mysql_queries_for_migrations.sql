-- ============================================
-- MySQL Queries for Migrations
-- ============================================

-- Migration 1: Add investigations_others to ophthalmologist_medical_records table
-- File: 2025_11_03_195838_add_investigations_others_to_ophthalmologist_medical_records_table.php

-- Check if column exists before adding (MySQL 5.7+)
SET @dbname = DATABASE();
SET @tablename = 'ophthalmologist_medical_records';
SET @columnname = 'investigations_others';
SET @preparedStatement = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname)
    ) > 0,
    "SELECT 'Column already exists.' AS result;",
    CONCAT("ALTER TABLE `", @tablename, "` ADD COLUMN `", @columnname, "` TEXT NULL AFTER `investigations`;")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- OR simpler version (if you're sure column doesn't exist):
-- ALTER TABLE `ophthalmologist_medical_records` 
-- ADD COLUMN `investigations_others` TEXT NULL AFTER `investigations`;


-- Migration 2: Add other snapshot fields to patient_appointments table
-- File: 2025_11_03_203401_add_other_snapshot_fields_to_patient_appointments_table.php

-- Add patient_type_of_treatment_other_snapshot column
SET @dbname = DATABASE();
SET @tablename = 'patient_appointments';
SET @columnname1 = 'patient_type_of_treatment_other_snapshot';
SET @preparedStatement1 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname1)
    ) > 0,
    "SELECT 'Column patient_type_of_treatment_other_snapshot already exists.' AS result;",
    CONCAT("ALTER TABLE `", @tablename, "` ADD COLUMN `", @columnname1, "` VARCHAR(255) NULL AFTER `patient_type_of_treatment`;")
));
PREPARE alterIfNotExists1 FROM @preparedStatement1;
EXECUTE alterIfNotExists1;
DEALLOCATE PREPARE alterIfNotExists1;

-- Add patient_other_diseases_other_snapshot column
SET @columnname2 = 'patient_other_diseases_other_snapshot';
SET @preparedStatement2 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname2)
    ) > 0,
    "SELECT 'Column patient_other_diseases_other_snapshot already exists.' AS result;",
    CONCAT("ALTER TABLE `", @tablename, "` ADD COLUMN `", @columnname2, "` VARCHAR(255) NULL AFTER `patient_other_diseases`;")
));
PREPARE alterIfNotExists2 FROM @preparedStatement2;
EXECUTE alterIfNotExists2;
DEALLOCATE PREPARE alterIfNotExists2;

-- OR simpler versions (if you're sure columns don't exist):
-- ALTER TABLE `patient_appointments` 
-- ADD COLUMN `patient_type_of_treatment_other_snapshot` VARCHAR(255) NULL AFTER `patient_type_of_treatment`;

-- ALTER TABLE `patient_appointments` 
-- ADD COLUMN `patient_other_diseases_other_snapshot` VARCHAR(255) NULL AFTER `patient_other_diseases`;


-- ============================================
-- Simple MySQL Queries for Migrations
-- (Use these if columns don't exist)
-- ============================================

-- Migration 1: Add investigations_others to ophthalmologist_medical_records table
ALTER TABLE `ophthalmologist_medical_records` 
ADD COLUMN `investigations_others` TEXT NULL AFTER `investigations`;


-- Migration 2: Add other snapshot fields to patient_appointments table
ALTER TABLE `patient_appointments` 
ADD COLUMN `patient_type_of_treatment_other_snapshot` VARCHAR(255) NULL AFTER `patient_type_of_treatment`;

ALTER TABLE `patient_appointments` 
ADD COLUMN `patient_other_diseases_other_snapshot` VARCHAR(255) NULL AFTER `patient_other_diseases`;


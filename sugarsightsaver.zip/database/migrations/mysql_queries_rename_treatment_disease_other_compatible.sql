-- ============================================
-- MySQL Queries for Migration: Rename Treatment/Disease Other Fields
-- Compatible with MySQL 5.7 and earlier MySQL 8.0 versions
-- ============================================

-- ============================================
-- UP Migration (Forward)
-- ============================================

SET @dbname = DATABASE();
SET @tablename = 'patient_appointments';

-- Step 1: Drop patient_type_of_treatment_other_snapshot if exists
SET @columnname1 = 'patient_type_of_treatment_other_snapshot';
SET @preparedStatement1 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname1)
    ) > 0,
    CONCAT("ALTER TABLE `", @tablename, "` DROP COLUMN `", @columnname1, "`;"),
    "SELECT 'Column patient_type_of_treatment_other_snapshot does not exist. Skipping.' AS result;"
));
PREPARE alterIfExists1 FROM @preparedStatement1;
EXECUTE alterIfExists1;
DEALLOCATE PREPARE alterIfExists1;

-- Step 2: Drop patient_other_diseases_other_snapshot if exists
SET @columnname2 = 'patient_other_diseases_other_snapshot';
SET @preparedStatement2 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname2)
    ) > 0,
    CONCAT("ALTER TABLE `", @tablename, "` DROP COLUMN `", @columnname2, "`;"),
    "SELECT 'Column patient_other_diseases_other_snapshot does not exist. Skipping.' AS result;"
));
PREPARE alterIfExists2 FROM @preparedStatement2;
EXECUTE alterIfExists2;
DEALLOCATE PREPARE alterIfExists2;

-- Step 3: Add patient_treatment_other if not exists
SET @columnname3 = 'patient_treatment_other';
SET @preparedStatement3 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname3)
    ) > 0,
    "SELECT 'Column patient_treatment_other already exists. Skipping.' AS result;",
    CONCAT("ALTER TABLE `", @tablename, "` ADD COLUMN `", @columnname3, "` VARCHAR(255) NULL AFTER `patient_type_of_treatment`;")
));
PREPARE alterIfNotExists3 FROM @preparedStatement3;
EXECUTE alterIfNotExists3;
DEALLOCATE PREPARE alterIfNotExists3;

-- Step 4: Add patient_disease_other if not exists
SET @columnname4 = 'patient_disease_other';
SET @preparedStatement4 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname4)
    ) > 0,
    "SELECT 'Column patient_disease_other already exists. Skipping.' AS result;",
    CONCAT("ALTER TABLE `", @tablename, "` ADD COLUMN `", @columnname4, "` VARCHAR(255) NULL AFTER `patient_other_diseases`;")
));
PREPARE alterIfNotExists4 FROM @preparedStatement4;
EXECUTE alterIfNotExists4;
DEALLOCATE PREPARE alterIfNotExists4;


-- ============================================
-- ALTERNATIVE: Manual Queries (if you know the state)
-- ============================================

-- If you're sure the old columns exist, use these directly:
-- ALTER TABLE `patient_appointments` DROP COLUMN `patient_type_of_treatment_other_snapshot`;
-- ALTER TABLE `patient_appointments` DROP COLUMN `patient_other_diseases_other_snapshot`;
-- ALTER TABLE `patient_appointments` ADD COLUMN `patient_treatment_other` VARCHAR(255) NULL AFTER `patient_type_of_treatment`;
-- ALTER TABLE `patient_appointments` ADD COLUMN `patient_disease_other` VARCHAR(255) NULL AFTER `patient_other_diseases`;


-- ============================================
-- DOWN Migration (Rollback) - Reverse the above
-- ============================================

-- Step 1: Drop patient_treatment_other if exists
SET @columnname5 = 'patient_treatment_other';
SET @preparedStatement5 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname5)
    ) > 0,
    CONCAT("ALTER TABLE `", @tablename, "` DROP COLUMN `", @columnname5, "`;"),
    "SELECT 'Column patient_treatment_other does not exist. Skipping.' AS result;"
));
PREPARE alterIfExists5 FROM @preparedStatement5;
EXECUTE alterIfExists5;
DEALLOCATE PREPARE alterIfExists5;

-- Step 2: Drop patient_disease_other if exists
SET @columnname6 = 'patient_disease_other';
SET @preparedStatement6 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname6)
    ) > 0,
    CONCAT("ALTER TABLE `", @tablename, "` DROP COLUMN `", @columnname6, "`;"),
    "SELECT 'Column patient_disease_other does not exist. Skipping.' AS result;"
));
PREPARE alterIfExists6 FROM @preparedStatement6;
EXECUTE alterIfExists6;
DEALLOCATE PREPARE alterIfExists6;

-- Step 3: Restore patient_type_of_treatment_other_snapshot if not exists
SET @columnname7 = 'patient_type_of_treatment_other_snapshot';
SET @preparedStatement7 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname7)
    ) > 0,
    "SELECT 'Column patient_type_of_treatment_other_snapshot already exists. Skipping.' AS result;",
    CONCAT("ALTER TABLE `", @tablename, "` ADD COLUMN `", @columnname7, "` VARCHAR(255) NULL AFTER `patient_type_of_treatment`;")
));
PREPARE alterIfNotExists7 FROM @preparedStatement7;
EXECUTE alterIfNotExists7;
DEALLOCATE PREPARE alterIfNotExists7;

-- Step 4: Restore patient_other_diseases_other_snapshot if not exists
SET @columnname8 = 'patient_other_diseases_other_snapshot';
SET @preparedStatement8 = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE
            (TABLE_SCHEMA = @dbname)
            AND (TABLE_NAME = @tablename)
            AND (COLUMN_NAME = @columnname8)
    ) > 0,
    "SELECT 'Column patient_other_diseases_other_snapshot already exists. Skipping.' AS result;",
    CONCAT("ALTER TABLE `", @tablename, "` ADD COLUMN `", @columnname8, "` VARCHAR(255) NULL AFTER `patient_other_diseases`;")
));
PREPARE alterIfNotExists8 FROM @preparedStatement8;
EXECUTE alterIfNotExists8;
DEALLOCATE PREPARE alterIfNotExists8;


import.meta.glob([
    '../images/**',
]);
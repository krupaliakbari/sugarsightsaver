/** 
 * 
 * Sales
 * 
**/

window.addEventListener("load", function(){
    try {
    
    /*
        =============================================
            Perfect Scrollbar | Recent Activities
        =============================================
    */
    const ps = new PerfectScrollbar(document.querySelector('.mt-container-ra'));

    } catch(e) {
        console.log(e);
    }
})